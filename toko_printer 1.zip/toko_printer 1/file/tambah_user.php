<?php
session_start();
require 'function.php';



if(isset($_POST["kirim"])){
    if(tambahuser($_POST) > 0){
    echo "
        <script type='text/javascript'>
            alert('tambah data user berhasil ditambahkan');
            window.location = 'user.php';
        </script>
    ";
}else{
    echo "
    <script type='text/javascript'>
        alert('tambah data user gagal, silahkan di cek kembali!');
        window.location = 'user.php';
    </script>
";
}
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
 
</head>
<body>
<div class="main">

   
    <div class="box">
        <h3>Tambah data resepsionis</h3>

        <form action="" method="POST">

            <label for="username">username</label>
            <input type="text" name="username" id="username" class="form-control">

            <label for="nama_lenkap">nama lengkap</label>
            <input type="text" name="nama_lengkap" id="nama lengkap" class="form-control">


            <label for="password">password</label>
            <input type="text" name="password" id="password" class="form-control">

            <label for="roles">roles</label>
            <select name="roles" class="form-control">
                <option value="Admin">Admin</option>
                <option value="Customer"> Customer</option>
            </select>

            <button type="submit" name="kirim" class="btn btn-primary btn-lg">tambah data</button>
  
        </form>
    </div>
</div>

</body>
</html>

