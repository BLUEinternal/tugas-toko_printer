<?php 
session_start();
require 'function.php';



$user= query("SELECT * FROM user");

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>produk</title>

</head>
<style>


.main{
    position: absolute;
    top: 80px;
   left: 400px;
 
  
}

table, td, th {
  border: 3px solid black;
}

table {
  border-collapse: collapse;

}

th {
  text-align: left;
}

.main h2{
  padding-left:50px;
}



</style>
<body>
<div class="navbar">
<ul>
  <li><a href="produk.php">produk</a></li>
  <li><a href="user.php">user</a></li>
 
</ul>

</div>

<div class="main">
    <h2>data user printer</h2>

    <a href="tambah_user.php">tambah data user</a>
    <table >
        <tr>
            <th>NO.</th>
            <th>username</th>
            <th>nama lengkap</th>
            <th>kelas</th>
            <th>nisn</th>
            <th>aksi</th>
        </tr>
        <?php $i = 1  ?>
        <?php foreach($user as $data) :   ?>
            <tr>
                <th><?=$i; ?></th>
                <th><?=$data["username"]; ?></th>
                <th><?=$data["nama_lengkap"]; ?></th>
                <th><?=$data["password"]; ?></th>
                <th><?=$data["roles"]; ?></th>
              
                <td>
                <a href="edit_user.php?id=<?=$data["id_user"]; ?>" >edit</a>
                <a href="hapus_user.php?id=<?=$data["id_user"]; ?>"onClick="return confirm('anda yakin ingin menghapus data ini')">hapus</a>
               </td>
              
            </tr>
            <?php $i++; ?>
        <?php  endforeach; ?>
    </table>
</div>
    
</body>
</html>