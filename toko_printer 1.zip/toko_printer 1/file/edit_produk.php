<?php

session_start();
require 'function.php';

$id = $_GET["id"];
$produk  = query("SELECT * FROM produk WHERE id_produk ='$id'")[0];




if(isset($_POST["kirim"])){
    if(editproduk($_POST) > 0){
    echo "
        <script type='text/javascript'>
            alert(' data produk berhasil di edit');
            window.location = 'produk.php';
        </script>
    ";
}else{
    echo "
    <script type='text/javascript'>
        alert('edit data produk gagal silahkan di cek kembali!');
        window.location = 'produk.php';
    </script>
";
}
}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>



</head>
<body>
<div class="main">
    <div class="box">
        <h3>edit Data produk</h3>

        <form action="" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id_produk" value="<?= $produk["id_produk"]; ?>"> <br>

           
            <label  for="nama_produk" >nama produk</label>
            <input type="text" name="nama_produk" id="nama_produk" class="form-control" value="<?= $produk["nama_produk"] ; ?>">
            
            <label for="harga_produk">harga produk</label>
            <input type="text" name="harga_produk" id="harga_produk" class="form-control" value="<?= $produk["harga_produk"] ; ?>">

         
            <label for="foto">foto</label>
            <input type="file" name="foto" id="foto" class="form-control" value="<?= $produk["foto"]; ?>">

            <label for="deskripsi">deskripsi</label>
            <input type="text" name="deskripsi" id="deskripsi" class="form-control" value="<?= $produk["deskripsi"] ; ?>">

            <label for="stock">stock</label>
            <input type="text" name="stock" id="stock" class="form-control" value="<?= $produk["stock"] ; ?>">


            <div class="mt-3">
             <button type="submit" name="kirim"  >edit data</button>
            </div>
  
        </form>
    </div>
</div>



</body>
</html>