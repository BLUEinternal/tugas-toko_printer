<?php 
session_start();
require 'function.php';



$produk = query("SELECT * FROM produk");

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>


.main{
    position: absolute;
    top: 80px;
   left: 100px;
 
  
}

table, td, th {
  border: 3px solid black;
}

table {
  border-collapse: collapse;

}

th {
  text-align: left;
}




</style>
<body>
<div class="navbar">
<ul>
  <li><a href="produk.php">produk</a></li>
  <li><a href="user.php">user</a></li>
 
</ul>

</div>



<div class="main">
    <h2>data barang produk printer</h2>

    <a href="tambah_produk.php">tambah  produk</a>
    <table>
        <tr>
            <th>NO.</th>
            <th>nama produk</th>
            <th>harga produk</th>
            <th>foto</th>
            <th>stock</th>
            <th>deskripsi</th>
            <th>Aksi</th>
        </tr>
        <?php $i = 1  ?>
        <?php foreach($produk as $data) :   ?>
            <tr>
                <td><?=$i; ?></td>
                <td><?=$data["nama_produk"]; ?></td>
                <td><?=$data["harga_produk"]; ?></td>
                <td><img src="../foto/<?=$data["foto"]; ?>" width="50px"></td>
                <td><?=$data["stock"]; ?></td>
                <td><?=$data["deskripsi"]; ?></td>
              
                <td>
                <a href="edit_produk.php?id=<?=$data["id_produk"]; ?>" >edit</a>
                <a href="hapus_produk.php?id=<?=$data["id_produk"]; ?>"onClick="return confirm('anda yakin ingin menghapus data ini')">hapus</a>
               </td>
              
            </tr>
            <?php $i++; ?>
        <?php  endforeach; ?>
    </table>
</div>
    
</body>
</html>

