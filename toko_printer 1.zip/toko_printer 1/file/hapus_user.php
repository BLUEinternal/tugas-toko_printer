<?php

require 'function.php';

$id = $_GET["id"];

if(hapususer($id) > 0){ 
    echo "
        <script type='text/javascript'>
            alert('data user berhasil di apus');
            window.location = 'user.php';
        </script>
    ";
}else{
    echo "
    <script type='text/javascript'>
        alert('data user gagal di hapus');
        window.location = 'user.php';
    </script>
";
}

?>